class Veterinaire_sanitaire():
    def init(self,nom_v_sanitaire,prenom_v_sanitaire,tel_v_sanitaire,mail_v_sanitaire):
     self.nom_v_sanitaire=nom_v_sanitaire
     self.prenom_v_sanitaire=prenom_v_sanitaire
     self.tel_v_sanitaire=tel_v_sanitaire
     self.mail_v_sanitaire=mail_v_sanitaire
veterinaire_sanitaire=Veterinaire_sanitaire('Abul','Karl','22','Abul.karl@proton.me')

