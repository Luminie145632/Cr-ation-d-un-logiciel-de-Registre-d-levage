class Veterinaire_traitant():
    def init(self,nom_v_traitant,prenom_v_traitant,tel_v_traitant,mail_v_traitant):
     self.nom_v_traitant=nom_v_traitant
     self.prenom_v_traitant=prenom_v_traitant
     self.tel_v_traitant=tel_v_traitant
     self.mail_v_traitant=mail_v_traitant
veterinaire_traitant=Veterinaire_traitant('Abul','Karl','22','Abul.karl@proton.me')



