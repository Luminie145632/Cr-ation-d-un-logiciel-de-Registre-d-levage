class Organisme_sanitaire():
    def init(self,nom_organisme,prenom_organisme,tel_organisme,mail_organisme,adresse):
     self.nom_organisme=nom_organisme
     self.prenom_organisme=prenom_organisme
     self.tel_organisme=tel_organisme
     self.mail_organisme=mail_organisme
     self.adresse=adresse
veterinaire_sanitaire=Organisme_sanitaire('Abul','Karl','22','Abul.karl@proton.me',' 5 rue station')

