class Referent_bien_etre():
    def init(self,nom_v_ref_bien_etre,prenom_v_ref_bien_etre,tel_v_ref_bien_etre,mail_v_ref_bien_etre):
     self.nom_v_ref_bien_etre=nom_v_ref_bien_etre
     self.prenom_v_ref_bien_etre=prenom_v_ref_bien_etre
     self.tel_v_ref_bien_etre=tel_v_ref_bien_etre
     self.mail_v_ref_bien_etre=mail_v_ref_bien_etre
referent_bien_etre=Referent_bien_etre('Abul','Karl','06 77 91 56 21','Abul.karl@proton.me')

