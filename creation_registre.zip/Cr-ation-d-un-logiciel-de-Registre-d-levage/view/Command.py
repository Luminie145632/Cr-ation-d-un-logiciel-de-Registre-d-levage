import os


class Command():
    def __init__(self):
     self=self         

def return_main_menu(self):
        self.destroy()
        os.system("python Accueil.py")