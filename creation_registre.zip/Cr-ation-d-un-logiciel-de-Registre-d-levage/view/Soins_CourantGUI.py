from tkinter import *
from PIL import Image, ImageTk
import os

class Soins_cournat(Frame):
    def __init__(self, fenetre, height, width, col_titles):
        super().__init__(fenetre)
        self.numberLines = height
        self.numberColumns = width
        self.col_titles = col_titles
        self.pack(fill=BOTH)

        tex1 = Label(self, text='Encadrement Zootechnique Sanitaire et Médical des Animaux', fg='cyan')
        tex1.grid(row=0, column=0, columnspan=8)

        # Ajout des titres de colonnes
        for j in range(self.numberColumns):
            col_title = Label(self, text=self.col_titles[j], width=20, relief="solid", bg="lightgray", anchor="w")
            col_title.grid(row=0, column=j, sticky='nsew')

        # Ajout des données du tableau
        self.data = []
        for i in range(1, self.numberLines + 1):
            line = []
            for j in range(self.numberColumns):
                cell = Entry(self, width=20)
                cell.grid(row=i, column=j, sticky='nsew')
                line.append(cell)
            self.data.append(line)

        # Configurer la gestion des colonnes pour qu'elles s'adaptent au contenu
        for j in range(self.numberColumns):
            self.grid_columnconfigure(j, weight=1)

        # Bouton pour ajouter une nouvelle ligne
        self.bouton_ajouter_ligne = Button(self, text="Ajouter une ligne", command=self.ajouter_ligne, width=20, height=1)
        self.bouton_ajouter_ligne.grid(row=self.numberLines + 1, columnspan=self.numberColumns, sticky='nsew')

        btn_mouvement_temporaire = Button(self, text="Retour au menu principal", command=  self.return_main_menu )#self.signaler_mouvement_temporaire)
        btn_mouvement_temporaire.grid(row=self.numberLines + 2, column=self.numberColumns, columnspan=self.numberColumns, sticky='nsew')

        # Ajout du Canvas
        self.can1 = Canvas(self, bg='blue', width=450, height=450)
        self.can1.grid(row=self.numberLines + 2, column=0, columnspan=self.numberColumns, pady=5)

        try:
        # Charger l'image avec PIL
         image = Image.open("/Creation_dun_logiciel_de_Registre_delevage/images/cheval_blanc.png")
        # Augmenter la taille de l'image (dans cet exemple, je l'ai doublée)
         image = image.resize((960, 540), Image.BICUBIC)
        # Convertir l'image en format Tkinter PhotoImage
         self.image = ImageTk.PhotoImage(image)
        
       
        # Afficher l'image sur le canvas
         self.can1.create_image(0, 0, anchor=NW, image=self.image)
        except Exception:
            print("eee") 

    def return_main_menu(self):
     self.destroy()
     os.system("python Accueil.py")



    def ajouter_ligne(self):
        # Cacher le bouton
        self.bouton_ajouter_ligne.grid_remove()

        # Ajouter une nouvelle ligne
        nouvelle_ligne = []
        for j in range(self.numberColumns):
            cell = Entry(self, width=20)
            cell.grid(row=self.numberLines + 2, column=j, sticky='nsew')
            nouvelle_ligne.append(cell)
        self.data.append(nouvelle_ligne)
        self.numberLines += 1

        # Afficher le bouton à la nouvelle position
        self.bouton_ajouter_ligne.grid(row=self.numberLines + 2, columnspan=self.numberColumns, sticky='nsew')

if __name__ == "__main__":
    fenetre = Tk()
    fenetre.title("")
    fenetre.geometry("1920x1080")
    try:
     fenetre.iconbitmap("/Creation_dun_logiciel_de_Registre_delevage/images/horse_sans_fond.ico")
     fenetre.resizable(height=True, width=True)
    except Exception:
     print("eee")
     label_principal = Label(fenetre, text="Intervention et soins courant")
    
    label_principal.pack()

    # Liste des titres des colonnes
    col_titles = ["Date", "Type d'intervention", "Intervenant (si vétérianire)", "Tratement", "N ordonnance", ""]

    fenetre_principale = Soins_cournat(fenetre, height=3, width=6, col_titles=col_titles)
    fenetre_principale.mainloop()