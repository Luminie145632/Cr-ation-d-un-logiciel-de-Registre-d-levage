[


 centre1={
 id='12';
 nb_chevaux='100';    
 lieu='bret'
 

 }
 centre2={
 id='10';
 nb_chevaux='150';    


 }










]